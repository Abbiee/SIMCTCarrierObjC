//
//  ViewController.m
//  SIMMessageController
//
//  Created by Abbie on 04/08/20.
//  Copyright © 2020 Abbie. All rights reserved.
//

#import "ViewController.h"
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>
#import<CoreTelephony/CTCallCenter.h>
#import<CoreTelephony/CTCall.h>
#import<CoreTelephony/CTCarrier.h>
#import<CoreTelephony/CTTelephonyNetworkInfo.h>

@interface ViewController ()<UINavigationControllerDelegate,MFMessageComposeViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

-(void)openMessageViewWithName:(NSString*)contactName withPhone:(NSString *)phone{

CTTelephonyNetworkInfo *networkInfo=[CTTelephonyNetworkInfo new];
    CTCarrier *carrier;
    NSDictionary *providers = [networkInfo serviceSubscriberCellularProviders];
    NSLog(@"%@", providers);
    for (NSString *aKey in providers) { CTCarrier *aCarrier = providers[aKey]; NSString *code = [aCarrier isoCountryCode]; NSLog(@"Country code: %@", code); }

    [self sendSMS:@"Abhi" recipientList:[NSMutableArray arrayWithObject:phone]];
}

 - (void)sendSMS:(NSString *)bodyOfMessage recipientList:(NSMutableArray *)recipients{
 MFMessageComposeViewController *controller1 = [[MFMessageComposeViewController alloc] init] ;
 controller1 = [[MFMessageComposeViewController alloc] init] ;
 if([MFMessageComposeViewController canSendText])
{
    controller1.body = bodyOfMessage;
    controller1.recipients = recipients;
    controller1.messageComposeDelegate = self;
    [self presentViewController:controller1 animated:YES completion:Nil];
 }
}
- (IBAction)smsAction:(id)sender {
    
    [self openMessageViewWithName:@"ABHI" withPhone:@"8157922023"];
}

- (CTCarrier *)firstCarrier:(NSDictionary<NSString *, CTCarrier *> *) carriers {
    for (NSString *key in carriers) {
        return carriers[key];
    }
    return nil;
}

@end
