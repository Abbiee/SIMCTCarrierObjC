//
//  SceneDelegate.h
//  SIMMessageController
//
//  Created by Abbie on 04/08/20.
//  Copyright © 2020 Abbie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

